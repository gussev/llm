package main

import (
	"net/url"
	"strings"
)

func ping() {
	parse := []string{
		"one plus one equals",
		"one plus one equals",
		"one plis one equal",
		"0+0=0"}
	evaluator := []string{"simple", "simple", "simple", "simple"}
	chatter := []string{"completer", "teller", "teller", "completer"}
	wait_for := []string{
		"{ \"error\":\"\", \"result\" :\"two\", \"last\":\"\" }",
		"{ \"error\":\"\", \"result\" :\"one plus one equals two\", \"last\":\"two\" }",
		"{ \"error\":\"word:plis could not be evaluated\", \"result\":\"\", \"last\":\"\" }",
		"{ \"error\":\"not able to evaluate expression\", \"result\":\"\", \"last\":\"\" }"}
	for ind := 0; ind < len(parse); ind++ {
		data := url.Values{}
		data.Set("parse", parse[ind])
		data.Set("evaluator", evaluator[ind])
		data.Set("chatter", chatter[ind])

		body := call_server(data)
		if strings.Compare(string(body), wait_for[ind]) != 0 {
			println(string(body))
			print_response(body)
		} else {
			println("ok:" + parse[ind])
		}
		delete(data, "parse")
		delete(data, "evaluator")
		delete(data, "chatter")
	}
}
