package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
)

func main() {
	//loader()
	//ping()
	teller()
}
func call_server(data url.Values) []byte {
	resp, err := http.PostForm("http://localhost:8080/llm", data)
	if err != nil {
		panic(err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)

	if err != nil {
		panic(err)
	}
	return body
}
func print_response(body []byte) {
	fmt.Println(string(body))
	var jsonRes map[string]interface{} // declaring a map for key names as string and values as interface
	_ = json.Unmarshal(body, &jsonRes)
	error := jsonRes["error"].(string)
	result := jsonRes["result"].(string)
	last := jsonRes["last"].(string)
	println("error:" + error + ",result:" + result + ",last:" + last)
}
