package main

import (
	"encoding/json"
	"net/url"
	"strings"
)

func teller() {
	parse := "one plus one equals"
	evaluator := "simple"
	chatter := "teller"
	wait_for := "{ \"error\":\"\", \"result\" :\"one plus one equals two\", \"last\":\"two\" }"
	data := url.Values{}
	data.Set("parse", parse)
	data.Set("evaluator", evaluator)
	data.Set("chatter", chatter)

	body := call_server(data)
	if strings.Compare(string(body), wait_for) != 0 {
		println(string(body))
		print_response(body)
	} else {
		println("ok:" + parse)
		println("response:" + string(body))
	}
	delete(data, "parse")
	delete(data, "evaluator")
	delete(data, "chatter")
	// second request
	wait_for = "{ \"error\":\"\", \"result\" :\"two plus eight equals ten\", \"last\":\"ten\" }"
	data = url.Values{}
	// get the value for the last key from the previous response
	var jsonRes map[string]interface{}
	_ = json.Unmarshal(body, &jsonRes)
	last := jsonRes["last"].(string)
	// arranging a new question
	data.Set("parse", last)
	data.Set("evaluator", evaluator)
	data.Set("chatter", chatter)
	body = call_server(data)
	// so, we do know what must be the answer
	if strings.Compare(string(body), wait_for) != 0 {
		println(string(body))
		print_response(body)
	} else {
		println("ok:" + last)
		println("response:" + string(body))
	}
	delete(data, "parse")
	delete(data, "evaluator")
	delete(data, "chatter")
	// and so on ...

}
